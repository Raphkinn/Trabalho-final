function validarFormulario() {
    
    var nome = document.getElementById('nome').value;
    var email = document.getElementById('email').value;
    var mensagem = document.getElementById('mensagem').value;
    var mensagemErro = document.getElementById('mensagem-erro');
    

    if (nome === "" || email === "" || mensagem === "") {
        mensagemErro.style.display = "block";  
        return false;  
    } else {
        mensagemErro.style.display = "none";  
        alert("Formulário enviado com sucesso!");
        return true;  
    }
}
