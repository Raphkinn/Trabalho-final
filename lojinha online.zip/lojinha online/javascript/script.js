let carrinho = [];

function adicionarCarrinho(nomeProduto, preco) {
    const produto = { nome: nomeProduto, preco: preco };
    carrinho.push(produto);
    exibirCarrinho();
}

function exibirCarrinho() {
    const carrinhoItens = document.getElementById("carrinho-itens");
    carrinhoItens.innerHTML = ""; 

    let total = 0;
    carrinho.forEach((produto, index) => {
        total += produto.preco;

        const item = document.createElement("div");
        item.classList.add("carrinho-item");

        item.innerHTML = `
            <p>${produto.nome} - R$ ${produto.preco}</p>
            <button onclick="removerDoCarrinho(${index})">Remover</button>
        `;

        carrinhoItens.appendChild(item);
    });

    const totalElement = document.getElementById("total");
    totalElement.innerText = `Total: R$ ${total.toFixed(2)}`;
}

function removerDoCarrinho(index) {
    carrinho.splice(index, 1);
    exibirCarrinho();
}

function finalizarCompra() {
    if (carrinho.length === 0) {
        alert("Seu carrinho está vazio.");
        return;
    }

    alert("Compra finalizada com sucesso!");
    carrinho = []; 
    exibirCarrinho();
}
